import { NumerologyResult } from "./NumerologyEngine"
import { NominalResult } from "./NominalEngine"
import { AstrologyResult } from "./AstrologyEngine"
import { CardsResult } from "./CardsEngine"
import { buildChapter } from "@/modules/interpreter/buildChapter"
import { LIFE_LESSON } from "@/modules/interpreter/lifeLesson"
import { DESTINY } from "@/modules/interpreter/destiny"



export interface InterpretationChapter {
  id: string
  title: string
  content: string
}

export interface InterpretationResult {
  chapters: InterpretationChapter[]
}

export class InterpretationEngine {

  execute(
    numerology: NumerologyResult,
    nominal: NominalResult,
    astrology: AstrologyResult,
    cards: CardsResult
  ): InterpretationResult {

    const chapters: InterpretationChapter[] = []

    const lifeLesson =
  LIFE_LESSON[numerology.lifeLesson] ?? {
    title: `Lição de Vida ${numerology.lifeLesson}`,
    intro: `Seu Número da Lição de Vida é ${numerology.lifeLesson}.`,
    meaning: "",
    gifts: "",
    challenges: "",
    mission: "",
    advice: ""
  }
  
const destiny =
  DESTINY[numerology.destiny] ?? {
    title: `Destino ${numerology.destiny}`,
    intro: `Seu Número de Destino é ${numerology.destiny}.`,
    meaning: "",
    gifts: "",
    challenges: "",
    mission: "",
    advice: ""
  }

chapters.push({
  id: "destiny",
  title: destiny.title,
  content: buildChapter(destiny)
})


chapters.push({
  id: "lifeLesson",
  title: lifeLesson.title,
  content: buildChapter(lifeLesson)
})
    chapters.push({
      id: "destiny",
      title: "Destino",
      content: `Seu número de Destino é ${numerology.destiny}.`
    })

    chapters.push({
      id: "expression",
      title: "Expressão",
      content: `Seu número de Expressão é ${nominal.expression}.`
    })

    chapters.push({
      id: "motivation",
      title: "Motivação",
      content: `Seu número de Motivação é ${nominal.motivation}.`
    })

    chapters.push({
      id: "impression",
      title: "Impressão",
      content: `Seu número de Impressão é ${nominal.impression}.`
    })

    chapters.push({
      id: "astrology",
      title: "Mapa Astrológico",
      content:
        `Sol: ${astrology.sun}\n` +
        `Lua: ${astrology.moon}\n` +
        `Ascendente: ${astrology.ascendant}`
    })

    return {
      chapters
    }

  }

}