import { ClientModel } from "@/models/Client"

import { calculateLifeLesson } from "@/modules/numerology/lifeLesson"
import { calculateDestiny } from "@/modules/numerology/destiny"
import { calculateExpression } from "@/modules/numerology/expression"
import { calculateMotivation } from "@/modules/numerology/motivation"
import { calculateImpression } from "@/modules/numerology/impression"
import { calculateMission } from "@/modules/numerology/mission"

export interface NumerologyResult {
  success: boolean

  lifeLesson: number
  destiny: number
  expression: number
  motivation: number
  impression: number
  mission: number

  message?: string
}

export class NumerologyEngine {

  execute(client: ClientModel): NumerologyResult {

    if (!client.hasBirthDate) {
      return {
        success: false,

        lifeLesson: 0,
        destiny: 0,
        expression: 0,
        motivation: 0,
        impression: 0,
        mission: 0,

        message: "Data de nascimento não informada."
      }
    }

    const birthDate = client.data.dataNascimento!
    const name = client.data.nome!

    const lifeLesson = calculateLifeLesson(birthDate)
    const destiny = calculateDestiny(birthDate)
    const expression = calculateExpression(name)
    const motivation = calculateMotivation(name)
    const impression = calculateImpression(name)
    const mission = calculateMission(lifeLesson, destiny)

    return {
      success: true,

      lifeLesson,
      destiny,
      expression,
      motivation,
      impression,
      mission,
    }

  }

}