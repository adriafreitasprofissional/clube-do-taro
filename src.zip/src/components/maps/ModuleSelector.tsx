"use client"

export interface ModuleSelection {
  numerology: boolean
  astrology: boolean
  nominal: boolean
  cards: boolean
  business: boolean
  couple: boolean
  baby: boolean
  house: boolean
  dating: boolean
}

interface ModuleSelectorProps {
  value: ModuleSelection
  onChange: (value: ModuleSelection) => void
}

const modules = [
  { key: "numerology", label: "Numerologia Cabalística" },
  { key: "astrology", label: "Astrologia" },
  { key: "nominal", label: "Mapa Nominal" },
  { key: "cards", label: "Cartas" },
  { key: "business", label: "Mapa Empresarial" },
  { key: "couple", label: "Mapa do Casal" },
  { key: "baby", label: "Mapa do Bebê" },
  { key: "house", label: "Mapa da Casa" },
  { key: "dating", label: "Mapa dos Namorados" },
] as const

export default function ModuleSelector({
  value,
  onChange,
}: ModuleSelectorProps) {
  function toggle(key: keyof ModuleSelection) {
    onChange({
      ...value,
      [key]: !value[key],
    })
  }

  return (
    <div className="grid gap-3 md:grid-cols-2">
      {modules.map((module) => (
        <label
          key={module.key}
          className="flex items-center gap-3 rounded-lg border p-4 cursor-pointer hover:bg-zinc-50"
        >
          <input
            type="checkbox"
            checked={value[module.key]}
            onChange={() => toggle(module.key)}
          />

          <span>{module.label}</span>
        </label>
      ))}
    </div>
  )
}