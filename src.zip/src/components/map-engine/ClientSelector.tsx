import { SearchClient } from "./SearchClient";

interface Props {
  onNext: () => void;
}

export function ClientSelector({
  onNext,
}: Props) {

  return (

    <div className="space-y-8">

      <div>

        <h2 className="text-3xl font-bold">
          Selecione um Cliente
        </h2>

        <p className="mt-2 text-zinc-400">
          Pesquise um cliente existente ou cadastre um novo.
        </p>

      </div>

      <SearchClient />

      <button
        onClick={onNext}
        className="rounded-xl bg-yellow-500 px-6 py-3 font-semibold text-black hover:bg-yellow-400"
      >
        Continuar
      </button>

    </div>

  );

}