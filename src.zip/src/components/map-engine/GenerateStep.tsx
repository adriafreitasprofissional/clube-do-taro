"use client";

import { useState } from "react";

export function GenerateStep() {
  const [gerando, setGerando] = useState(false);
  const [resultado, setResultado] = useState<any>(null);

  async function gerarMapa() {
    try {
      setGerando(true);

      const response = await fetch("/api/map/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          nome: "Ivone",
          dataNascimento: "1980-01-01",
          horaNascimento: "12:00",
          cidade: "São Paulo",
          estado: "SP",
          pais: "Brasil",
        }),
      });

      const data = await response.json();

      setResultado(data);

    } catch (error) {

      console.error(error);
      alert("Erro ao gerar mapa.");

    } finally {

      setGerando(false);

    }
  }

  return (

    <div className="space-y-8">

      <div className="rounded-3xl border border-yellow-500/20 bg-[#22163A] p-10">

        <h1 className="text-4xl font-bold text-yellow-400">
          Mapa Premium
        </h1>

        <p className="mt-2 text-zinc-300">
          Clube do Tarô • AF Framework
        </p>

        <button
          onClick={gerarMapa}
          disabled={gerando}
          className="mt-8 w-full rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-400 py-5 text-xl font-bold text-[#22163A]"
        >
          {gerando ? "GERANDO MAPA..." : "GERAR MAPA"}
        </button>

      </div>

      {resultado && (

        <>

          <div className="rounded-3xl bg-[#22163A] border border-yellow-500/20 p-8">

            <h2 className="text-2xl font-bold text-yellow-400">
              ⭐ Numerologia Cabalística
            </h2>

            <div className="grid md:grid-cols-3 gap-6 mt-8">

              <div className="rounded-2xl bg-[#2B1F46] p-6">

                <p className="text-zinc-400">
                  Lição de Vida
                </p>

                <p className="text-5xl font-bold text-yellow-400 mt-3">
                  {resultado.numerology.lifeLesson}
                </p>

              </div>

              <div className="rounded-2xl bg-[#2B1F46] p-6">

                <p className="text-zinc-400">
                  Destino
                </p>

                <p className="text-5xl font-bold text-yellow-400 mt-3">
                  {resultado.numerology.destiny}
                </p>

              </div>

              <div className="rounded-2xl bg-[#2B1F46] p-6">

                <p className="text-zinc-400">
                  Expressão
                </p>

                <p className="text-5xl font-bold text-yellow-400 mt-3">
                  {resultado.numerology.expression}
                </p>

              </div>

            </div>

          </div>

          <div className="rounded-3xl bg-[#22163A] border border-yellow-500/20 p-8">

            <h2 className="text-2xl font-bold text-yellow-400">
              🌙 Astrologia
            </h2>

            <div className="grid md:grid-cols-3 gap-6 mt-8">

              <div className="rounded-2xl bg-[#2B1F46] p-6">

                <p className="text-zinc-400">
                  Sol
                </p>

                <p className="text-xl mt-3">
                  {resultado.astrology.sun}
                </p>

              </div>

              <div className="rounded-2xl bg-[#2B1F46] p-6">

                <p className="text-zinc-400">
                  Lua
                </p>

                <p className="text-xl mt-3">
                  {resultado.astrology.moon}
                </p>

              </div>

              <div className="rounded-2xl bg-[#2B1F46] p-6">

                <p className="text-zinc-400">
                  Ascendente
                </p>

                <p className="text-xl mt-3">
                  {resultado.astrology.ascendant}
                </p>

              </div>

            </div>

          </div>

          <div className="rounded-3xl bg-[#22163A] border border-yellow-500/20 p-8">

            <h2 className="text-2xl font-bold text-yellow-400">
              ✨ Interpretação
            </h2>

            <div className="mt-6 rounded-2xl bg-[#2B1F46] p-6">

              <p className="leading-8 text-zinc-200">

                {resultado.interpretation?.summary ??
                  "A interpretação completa será exibida aqui."}

              </p>

            </div>

          </div>

          <button
            className="w-full rounded-2xl border border-yellow-500 py-5 text-xl font-bold text-yellow-400 hover:bg-yellow-500 hover:text-[#22163A] transition"
          >
            BAIXAR PDF PREMIUM
          </button>

        </>

      )}

    </div>

  );

}