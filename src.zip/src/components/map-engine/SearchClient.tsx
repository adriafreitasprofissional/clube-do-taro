"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { ClientCard } from "./ClientCard";

interface Client {
  id: string;
  nome: string;
  email: string;
  plano: string;
  status: string;
}

export function SearchClient() {
  const [search, setSearch] = useState("");
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);

  useEffect(() => {
    async function loadClients() {
      if (search.length < 3) {
        setClients([]);
        return;
      }

      setLoading(true);

      const { data } = await supabase
        .from("club_clients")
        .select("id,nome,email,plano,status,whatsapp")
        .eq("status", "ativo")
        .or(
          `nome.ilike.%${search}%,email.ilike.%${search}%,whatsapp.ilike.%${search}%`
        )
        .order("nome")
        .limit(10);

      setClients(data ?? []);
      setLoading(false);
    }

    loadClients();
  }, [search]);

  if (selectedClient) {
    return (
      <div className="rounded-3xl border border-yellow-500/20 bg-[#151221] p-8">

        <h2 className="text-2xl font-bold text-yellow-400">
          Cliente Selecionado
        </h2>

        <div className="mt-6 space-y-2">

          <p className="text-xl font-semibold">
            {selectedClient.nome}
          </p>

          <p className="text-zinc-400">
            {selectedClient.email}
          </p>

          <p className="text-yellow-400">
            {selectedClient.plano}
          </p>

        </div>

        <button
          onClick={() => setSelectedClient(null)}
          className="mt-6 rounded-xl border border-zinc-700 px-5 py-3"
        >
          Alterar Cliente
        </button>

      </div>
    );
  }

  return (
    <div className="space-y-6">

      <input
        type="text"
        placeholder="Digite o nome, e-mail ou WhatsApp..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full rounded-xl border border-zinc-700 bg-zinc-900 p-4"
      />

      {search.length < 3 && (
        <div className="rounded-3xl border border-zinc-800 bg-zinc-900/60 p-12 text-center">

          <div className="text-6xl mb-6">
            🔍
          </div>

          <h3 className="text-2xl font-bold text-white">
            Encontre um cliente
          </h3>

          <p className="mt-3 text-zinc-400 max-w-xl mx-auto">
            Digite pelo menos <strong>3 letras</strong> do nome,
            e-mail ou WhatsApp.
          </p>

          <div className="my-8 flex items-center">

            <div className="flex-1 border-t border-zinc-700"></div>

            <span className="mx-4 text-zinc-500">
              ou
            </span>

            <div className="flex-1 border-t border-zinc-700"></div>

          </div>

          <button className="rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-400 px-8 py-4 font-bold text-[#151221]">
            + Cadastrar Novo Cliente
          </button>

        </div>
      )}

      {search.length >= 3 && loading && (
        <p className="text-zinc-400">
          Pesquisando...
        </p>
      )}

      {search.length >= 3 &&
        !loading &&
        clients.map((client) => (
          <ClientCard
            key={client.id}
            client={client}
            onSelect={() => setSelectedClient(client)}
          />
        ))}

    </div>
  );
}