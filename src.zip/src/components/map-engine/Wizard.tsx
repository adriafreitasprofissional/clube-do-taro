"use client";

import { useState } from "react";

import { ClientSelector } from "./ClientSelector";
import { BirthStep } from "./BirthStep";
import { GenerateStep } from "./GenerateStep";

export function Wizard() {

  const [step, setStep] = useState(1);

  return (

    <div className="mx-auto max-w-7xl p-10">

      <h1 className="text-4xl font-bold text-yellow-400">
        Motor de Mapas Premium
      </h1>

      <p className="mt-2 text-zinc-400">
        AF Framework
      </p>

      <div className="mt-10">

        {step === 1 && (
          <ClientSelector
            onNext={() => setStep(2)}
          />
        )}

        {step === 2 && (
          <BirthStep
            onNext={() => setStep(3)}
          />
        )}

        {step === 3 && (
          <GenerateStep />
        )}

      </div>

    </div>

  );

}