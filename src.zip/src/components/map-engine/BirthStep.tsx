"use client";

import { useState } from "react";

interface Props {
  onNext: () => void;
}

export function BirthStep({
  onNext,
}: Props) {

  const [estado, setEstado] = useState("SP");

  return (

    <div className="rounded-3xl border border-zinc-800 bg-zinc-900 p-10 space-y-8">

      <div>

        <h2 className="text-3xl font-bold text-yellow-400">
          Dados de Nascimento
        </h2>

        <p className="mt-2 text-zinc-400">
          Complete os dados para gerar o mapa.
        </p>

      </div>

      <div className="grid md:grid-cols-2 gap-6">

        <div>

          <label className="mb-2 block text-sm text-zinc-400">
            Data de nascimento
          </label>

          <input
            type="date"
            className="w-full rounded-xl border border-zinc-700 bg-zinc-950 p-4"
          />

        </div>

        <div>

          <label className="mb-2 block text-sm text-zinc-400">
            Hora de nascimento
          </label>

          <input
            type="time"
            className="w-full rounded-xl border border-zinc-700 bg-zinc-950 p-4"
          />

        </div>

        <div>

          <label className="mb-2 block text-sm text-zinc-400">
            Cidade
          </label>

          <input
            placeholder="Cidade de nascimento"
            className="w-full rounded-xl border border-zinc-700 bg-zinc-950 p-4"
          />

        </div>

        <div>

          <label className="mb-2 block text-sm text-zinc-400">
            Estado
          </label>

          <select
            value={estado}
            onChange={(e) => setEstado(e.target.value)}
            className="w-full rounded-xl border border-zinc-700 bg-zinc-950 p-4"
          >
            <option>AC</option>
            <option>AL</option>
            <option>AP</option>
            <option>AM</option>
            <option>BA</option>
            <option>CE</option>
            <option>DF</option>
            <option>ES</option>
            <option>GO</option>
            <option>MA</option>
            <option>MT</option>
            <option>MS</option>
            <option>MG</option>
            <option>PA</option>
            <option>PB</option>
            <option>PR</option>
            <option>PE</option>
            <option>PI</option>
            <option>RJ</option>
            <option>RN</option>
            <option>RS</option>
            <option>RO</option>
            <option>RR</option>
            <option>SC</option>
            <option>SP</option>
            <option>SE</option>
            <option>TO</option>
          </select>

        </div>

        <div className="md:col-span-2">

          <label className="mb-2 block text-sm text-zinc-400">
            País
          </label>

          <input
            value="Brasil"
            readOnly
            className="w-full rounded-xl border border-zinc-700 bg-zinc-800 p-4"
          />

        </div>

      </div>

      <button
        onClick={onNext}
        className="w-full rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-400 py-5 text-xl font-bold text-[#151221]"
      >
        Salvar e Continuar
      </button>

    </div>

  );

}