import { InterpretationData } from "./types"

export const LIFE_LESSON: Record<number, InterpretationData> = {

  1: {
    title: "Lição de Vida 1",
    intro: "Seu Número da Lição de Vida é 1.",
    meaning: "O número 1 representa liderança e iniciativa.",
    gifts: "Você possui forte capacidade de iniciar projetos.",
    challenges: "Evite autoritarismo e impaciência.",
    mission: "Aprender a liderar com equilíbrio.",
    advice: "Confie na sua capacidade de construir seu próprio caminho."
  },

  2: {
    title: "Lição de Vida 2",
    intro: "Seu Número da Lição de Vida é 2.",
    meaning: "O número 2 representa cooperação e sensibilidade.",
    gifts: "Você aproxima pessoas e cria harmonia.",
    challenges: "Evite depender da aprovação dos outros.",
    mission: "Aprender a confiar na própria intuição.",
    advice: "Valorize sua sensibilidade sem perder sua força."
  },

  6: {
    title: "Lição de Vida 6",
    intro: "Seu Número da Lição de Vida é 6.",
    meaning: "O número 6 representa amor, família e responsabilidade.",
    gifts: "Você nasceu para cuidar, acolher e harmonizar.",
    challenges: "Não carregue responsabilidades que não são suas.",
    mission: "Construir equilíbrio entre cuidar dos outros e cuidar de si.",
    advice: "O amor também começa pelo autocuidado."
  },

  11: {
    title: "Lição de Vida 11",
    intro: "Seu Número da Lição de Vida é 11.",
    meaning: "O Mestre 11 representa inspiração espiritual.",
    gifts: "Grande percepção intuitiva.",
    challenges: "Controlar ansiedade e excesso de sensibilidade.",
    mission: "Inspirar pessoas através da espiritualidade.",
    advice: "Confie na sua conexão espiritual."
  },

  22: {
    title: "Lição de Vida 22",
    intro: "Seu Número da Lição de Vida é 22.",
    meaning: "O Mestre 22 representa construção e realização.",
    gifts: "Capacidade de realizar grandes projetos.",
    challenges: "Não desperdiçar seu potencial.",
    mission: "Materializar sonhos coletivos.",
    advice: "Transforme ideias em realizações."
  },

  33: {
    title: "Lição de Vida 33",
    intro: "Seu Número da Lição de Vida é 33.",
    meaning: "O Mestre 33 representa amor universal.",
    gifts: "Dom para ensinar e curar.",
    challenges: "Evitar sacrificar-se em excesso.",
    mission: "Servir através do amor.",
    advice: "Equilibre serviço e autocuidado."
  }

}