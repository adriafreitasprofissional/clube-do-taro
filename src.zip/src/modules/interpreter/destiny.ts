import { InterpretationData } from "./types"

export const DESTINY: Record<number, InterpretationData> = {

  1: {
    title: "Destino 1",
    intro: "Seu Número de Destino é 1.",
    meaning: "Você nasceu para abrir caminhos e liderar.",
    gifts: "Iniciativa, coragem e independência.",
    challenges: "Controlar o ego e a impaciência.",
    mission: "Aprender a liderar inspirando pessoas.",
    advice: "Use sua força para construir e não para dominar."
  },

  2: {
    title: "Destino 2",
    intro: "Seu Número de Destino é 2.",
    meaning: "Seu destino está ligado à cooperação.",
    gifts: "Diplomacia e sensibilidade.",
    challenges: "Evitar insegurança.",
    mission: "Construir pontes entre pessoas.",
    advice: "Confie na sua intuição."
  },

  6: {
    title: "Destino 6",
    intro: "Seu Número de Destino é 6.",
    meaning: "Seu destino está ligado ao amor, à família e ao cuidado.",
    gifts: "Acolhimento e responsabilidade.",
    challenges: "Não assumir problemas dos outros.",
    mission: "Ser fonte de equilíbrio.",
    advice: "Cuide de si com o mesmo carinho que dedica aos demais."
  },

  11: {
    title: "Destino 11",
    intro: "Seu Número de Destino é 11.",
    meaning: "Destino de elevada inspiração espiritual.",
    gifts: "Intuição e percepção.",
    challenges: "Ansiedade e excesso de sensibilidade.",
    mission: "Inspirar pessoas.",
    advice: "Confie na sua missão."
  },

  22: {
    title: "Destino 22",
    intro: "Seu Número de Destino é 22.",
    meaning: "Destino voltado para grandes construções.",
    gifts: "Capacidade de realizar grandes projetos.",
    challenges: "Não limitar seu potencial.",
    mission: "Transformar sonhos em realidade.",
    advice: "Pense grande."
  },

  33: {
    title: "Destino 33",
    intro: "Seu Número de Destino é 33.",
    meaning: "Destino ligado ao amor universal.",
    gifts: "Ensinar, orientar e curar.",
    challenges: "Evitar o excesso de sacrifício.",
    mission: "Servir ao próximo.",
    advice: "Ajude sem esquecer de si."
  }

}