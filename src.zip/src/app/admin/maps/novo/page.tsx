"use client"

import { useState } from "react"
import ModuleSelector, {
  ModuleSelection,
} from "@/components/maps/ModuleSelector"

import ClientForm from "@/components/maps/ClientForm"

const initialModules: ModuleSelection = {
  numerology: false,
  astrology: false,
  nominal: false,
  cards: false,
  business: false,
  couple: false,
  baby: false,
  house: false,
  dating: false,
}


export default function NovoMapaPage() {
  const [modules, setModules] = useState(initialModules)

  return (
    <div className="mx-auto max-w-5xl p-8">

      <h1 className="text-3xl font-bold">
        Novo Mapa AF Framework
      </h1>

      <p className="mt-2 text-zinc-500">
        Escolha os módulos que farão parte deste mapa.
      </p>

      <div className="mt-8">
  <ModuleSelector
    value={modules}
    onChange={setModules}
  />
</div>

<div className="mt-8">
  
  <ClientForm
    showAstrology={modules.astrology}
  />
  
</div>

<div className="mt-10 rounded-xl border p-6">

</div>

      <div className="mt-10 rounded-xl border p-6">

        <h2 className="font-semibold text-lg">
          Módulos Selecionados
        </h2>

        <pre className="mt-4 text-sm">
          {JSON.stringify(modules, null, 2)}
        </pre>

      </div>

    </div>
  )
}