export { default } from "./Hero";
